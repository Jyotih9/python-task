# syntax
# complex_number = a + bj

# Declaring a Complex Number:
z = 2 + 3j
print(z)  # Output: (2+3j)

# Creating a Complex Number using complex():
z = complex(4, -5)
print(z)  # Output: (4-5j)

# Accessing Real and Imaginary Parts:
z = 2 + 3j
print(z.real)  # Output: 2.0
print(z.imag)  # Output: 3.0

# Calculating Conjugate:
z = 2 + 3j
print(z.conjugate())  # Output: (2-3j)

# Calculating Magnitude (Absolute Value):
z = 3 - 4j
print(abs(z))  # Output: 5.0

# Calculating Phase Angle:
import cmath
z = 1 + 1j
print(cmath.phase(z))  # Output: 0.7853981633974483 (radians)

# Raising a Complex Number to a Power:
z1 = 2 + 3j
z2 = pow(z1, 2)
print(z2)  # Output: (-5+12j)

# Exponential of a Complex Number:
import cmath
z = 1 + 1j
print(cmath.exp(z))  # Output: (1.4686939399158851+2.2873552871788423j)

# Natural Logarithm of a Complex Number:
import cmath
z = 1 + 1j
print(cmath.log(z))  # Output: (0.34657359027997264+0.7853981633974483j)

# Square Root of a Complex Number:
import cmath
z = 4 + 4j
print(cmath.sqrt(z))  # Output: (2+2j)