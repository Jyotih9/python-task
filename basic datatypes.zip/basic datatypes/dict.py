# syntax
# my_dict = {key1: value1, key2: value2, key3: value3, ...}

# Creating an empty dictionary:
empty_dict = {}
print(empty_dict)

# Creating a dictionary with key-value pairs:
my_dict = {'apple': 5, 'banana': 3, 'orange': 8}
print(my_dict)

# Accessing values using keys:
print(my_dict['apple'])  # Output: 5
print(my_dict['banana'])

# Adding a new key-value pair:
my_dict={'apple':5,'banana':3,'orange':8}
my_dict['grape'] = 4
print(my_dict)

# Checking if a key exists:
if 'banana' in my_dict:
    print("Banana is present!")

# Iterating through keys:
for key in my_dict.keys():
    print(key)

# Iterating through values:
for value in my_dict.values():
    print(value)        

# Iterating through key-value pairs:
for key, value in my_dict.items():
    print(key, value)

# Removing a key-value pair:
del my_dict['orange']

# Clearing the dictionary:
my_dict.clear()    