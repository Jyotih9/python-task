# syntax
float_variable = 3.14

# Declaration and basic operations:
a = 3.5
b = 2.25
print(a + b)  # Addition
print(a - b)  # Subtraction
print(a * b)  # Multiplication
print(a / b)  # Division

# Converting string to float:
str_float = "3.14"
float_value = float(str_float)
print(float_value)

# Rounding a float:
pi = 3.14159265359
rounded_pi = round(pi, 2)
print(rounded_pi)

# Finding maximum and minimum:
numbers = [3.14, 2.71, 1.618]
print(max(numbers))
print(min(numbers))

# Calculating sum:
numbers = [1.5, 2.5, 3.5]
print(sum(numbers))

# Absolute value:
x = -3.14
print(abs(x))

# Power function:
x = 2.0
y = 3.0
print(pow(x, y))  # equivalent to x ** y

#Converting float to integer:
x = 3.99
print(int(x))  # Outputs: 3

# Hexadecimal representation:
x = 10.5
print(hex(id(x)))

# Infinity and NaN:
positive_infinity = float('inf')
negative_infinity = float('-inf')
not_a_number = float('nan')
print(positive_infinity, negative_infinity, not_a_number)

