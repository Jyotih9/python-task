# syntax 
x=10
y=-5
z=0

# built_in function
# int() 
num_str = "123"
num_int = int(num_str)  # Convert string to integer

# abs()
absolute_value = abs(-10)  # Returns 10

# divmod()
quotient, remainder = divmod(10, 3)  # Returns (3, 1) - quotient = 3, remainder = 1

# pow()
result = pow(2, 3)  # Returns 8 (2 raised to the power of 3)

# examples
# Example 1: Simple addition
result = 5 + 3  # result = 8
print(result)

# Example 2: Subtraction
result = 10 - 7  # result = 3
print(result)

# Example 3: Multiplication
result = 6 * 4  # result = 24
print(result)

# Example 4: Division
result = 20 / 5  # result = 4.0 (Note: division always returns a float)
print(result)

# Example 5: Exponentiation
result = 2 ** 3  # result = 8
print(result)

# Example 6: Modulus
result = 17 % 5  # result = 2 (remainder of 17 divided by 5)s
print(result)

# Example 7: Absolute value
result = abs(-10)  # result = 10

# Example 8: Quotient and remainder
quotient, remainder = divmod(10, 3)  # quotient = 3, remainder = 1
print(quotient,remainder)

# Example 9: Converting string to integer
num_str = "123"
num_int = int(num_str)  # num_int = 123

# Example 10: Checking if a number is an integer
is_integer = isinstance(10, int)  # Returns True