# syntax
# list_name = [element1, element2, ..., elementN]

# Creating a List:
my_list = [1, 2, 3, 4, 5]

# Accessing Elements of a List:
my_list = [1, 2, 3, 4, 5]
print(my_list[0])  # Output: 1
print(my_list[-1]) # Output: 5 (Negative index starts from the end)

# Modifying Elements of a List:
my_list = [1, 2, 3, 4, 5]
my_list[2] = 10
print(my_list)  # Output: [1, 2, 10, 4, 5]

# Appending Elements to a List:
my_list = [1, 2, 3]
my_list.append(4)
print(my_list)  # Output: [1, 2, 3, 4]

# Extending a List with Another List:
my_list = [1, 2, 3]
other_list = [4, 5, 6]
my_list.extend(other_list)
print(my_list)  # Output: [1, 2, 3, 4, 5, 6]

#Inserting an Element at a Specific Position:
my_list = [1, 2, 3, 4, 5]
my_list.insert(2, 10)
print(my_list)  # Output: [1, 2, 10, 3, 4, 5]

# Removing an Element from a List:
my_list = [1, 2, 3, 4, 5]
my_list.remove(3)
print(my_list)  # Output: [1, 2, 4, 5]

# Popping an Element from a List:
my_list = [1, 2, 3, 4, 5]
popped_element = my_list.pop()
print(popped_element)  # Output: 5



