# syntax
# set_name = {element1, element2, ..., elementN}

# Creating a Set:
my_set = {1, 2, 3, 4, 5}
print(my_set)

# Adding Elements to a Set:
my_set = {1, 2, 3}
my_set.add(4)
print(my_set)  # Output: {1, 2, 3, 4}

set={1,2,3,4,5,6}
set.add(10)
print(set)

a={10,20,30,40,50,60,70,80}
a.add(90)
print(a)

b={"monday","tuesday","wednesday","thursday","friday"}
b.add("sunday")
print(b)

# Removing Elements from a Set:
my_set = {1, 2, 3}
my_set.remove(3)
print(my_set)  # Output: {1, 2}

set={10,20,30,40}
set.remove(20)
print(set)

a={"monday","tuesday","wednesday","thrusday"}
a.remove("monday")
print(a)

# Discarding Elements from a Set:
my_set = {1, 2, 3}
my_set.discard(3)
print(my_set)  # Output: {1, 2}

set={10,20,30}
set.discard(20)
print(set)

a={"monday","tuesday","wednesday","thursday"}
a.discard("tuesday")
print(a)

# Popping an Element from a Set:
my_set = {1, 2, 3}
popped_element = my_set.pop()
print(popped_element)  # Output: An arbitrary element from the set

my_set={10,20,30}
popped_element=my_set.pop()
print(popped_element)

# Clearing a Set:
my_set = {1, 2, 3}
my_set.clear()
print(my_set)  # Output: set()

set={10,20,30}
set.clear()
print(set)

# Set Union:
set1 = {1, 2, 3}
set2 = {3, 4, 5}
union_set = set1.union(set2)
print(union_set)  # Output: {1, 2, 3, 4, 5}

set3={10,20,30}
set4={10,40,50}
union_set=set2.union(set4)
print(union_set)

# Set Intersection:
set1 = {1, 2, 3}
set2 = {3, 4, 5}
intersection_set = set1.intersection(set2)
print(intersection_set)  # Output: {3}

# Set Difference:
set1 = {1, 2, 3}
set2 = {3, 4, 5}
difference_set = set1.difference(set2)
print(difference_set)  # Output: {1, 2}

# Set Symmetric Difference:
set1 = {1, 2, 3}
set2 = {3, 4, 5}
symmetric_difference_set = set1.symmetric_difference(set2)
print(symmetric_difference_set)  # Output: {1, 2, 4, 5}