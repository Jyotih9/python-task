# syntax
string_variable = 'Hello, World!'
#  or
string_variable = "Hello, World!"

# Length of a String:
string = "Hello, World!"
print(len(string))  # Output: 13

# Converting Other Data Types to String:
number = 42
string_number = str(number)
print(string_number)  # Output: '42'

# Converting Case:
string = "hello, WORLD!"
print(string.upper())     # Output: 'HELLO, WORLD!'
print(string.lower())     # Output: 'hello, world!'
print(string.capitalize()) # Output: 'Hello, world!'

# Counting Substrings:
string = "How much wood would a woodchuck chuck if a woodchuck could chuck wood?"
print(string.count("wood")) 

# Finding Substrings:
string = "Hello, World!"
print(string.find("World"))  # Output: 7
print(string.index("World")) # Output: 7

# Splitting and Joining:
string = "apple,banana,orange"
fruits_list = string.split(",")
print(fruits_list)  # Output: ['apple', 'banana', 'orange']

delimiter = " "
words = ["Hello", "world"]
sentence = delimiter.join(words)
print(sentence)  # Output: 'Hello world'

# Checking if a String Starts/Ends with a Substring:
string = "Hello, World!"
print(string.startswith("Hello"))  # Output: True
print(string.endswith("World!"))   # Output: True

# Removing Leading and Trailing Whitespaces:
string = "   Hello, World!   "
print(string.strip())  # Output: 'Hello, World!'

# Replacing Substrings:
string = "Hello, World!"
new_string = string.replace("Hello", "Hi")
print(new_string)  # Output: 'Hi, World!'

# Checking String Contents:
string = "12345"
print(string.isdigit())  # Output: True
print(string.isalpha())  # Output: False