# syntax
# tuple_name = (element1, element2, ..., elementN)

# Creating a Tuple:
my_tuple = (1, 2, 3, 4, 5)

# Accessing Elements of a Tuple:
my_tuple = (1, 2, 3, 4, 5)
print(my_tuple[0])  # Output: 1
print(my_tuple[-1]) # Output: 5 (Negative index starts from the end)

# Immutable Nature of Tuples:
my_tuple = (1, 2, 3)
# Attempting to modify a tuple will result in an error
# my_tuple[0] = 10

# Counting Occurrences of an Element:
my_tuple = (1, 2, 3, 2, 4, 2, 5)
print(my_tuple.count(2))  # Output: 3

# Finding Index of an Element:
my_tuple = (1, 2, 3, 4, 5)
index = my_tuple.index(3)
print(index)  # Output: 2

# Length of a Tuple:
my_tuple = (1, 2, 3, 4, 5)
print(len(my_tuple))  # Output: 5

# Iterating Through a Tuple:
my_tuple = (1, 2, 3, 4, 5)
for element in my_tuple:
    print(element)

# Tuple Packing and Unpacking:
# Packing
my_tuple = 1, 2, 3
# Unpacking
a, b, c = my_tuple
print(a, b, c)  # Output: 1 2 3

# Using Tuples as Keys in Dictionaries:
my_dict = {('John', 'Doe'): 30, ('Jane', 'Doe'): 25}
print(my_dict[('John', 'Doe')])  # Output: 30

# Returning Multiple Values from Functions:
def get_values():
    return 1, 2, 3

a, b, c = get_values()
print(a, b, c)  # Output: 1 2 3
